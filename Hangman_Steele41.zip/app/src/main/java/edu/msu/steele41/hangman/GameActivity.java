package edu.msu.steele41.hangman;


import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class GameActivity extends AppCompatActivity {

    Words guessWord;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);

         TextView textElement = (TextView) findViewById(R.id.GuessText);
         textElement.setText(guessWord.word());

         ImageView img= (ImageView) findViewById(R.id.image);
         img.setImageResource(R.drawable.hm0);

    }

}
