package edu.msu.steele41.hangman;


import android.content.Context;
import android.graphics.Canvas;


/**
 * Created by Jason Steele on 11/18/2015.
 */
public class Game{


    int n = 0;

    //guess = guess.substring(0, i) + letter + guess.substring(i+1);

    int hangImages[] = {R.drawable.hm0,R.drawable.hm1,R.drawable.hm2,R.drawable.hm3,R.drawable.hm4,R.drawable.hm5,R.drawable.hm6};

    private char[][] letters = {{'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I'},
            {'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R'},
            {'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', ' '}};

    public Game(Context context) {
    }





    public void draw(Canvas canvas) {
    }



}

