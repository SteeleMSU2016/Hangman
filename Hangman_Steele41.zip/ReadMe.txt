Exam 1


Jason William Steele.

So basically I have a layout in both portrait and Landscape.

I never did figure out how to create the keyboard.

I keep trying to set up a click method that installs a random word when new game is 
typed, but my attempts all seem to crash the system.  Cannot figure out the error.

I created an array of hangman views.  The point was to test the Letter to the word.  If 
it failed it would reassign the ImageView to the next view in the  array.

after the 8th image is reached it would stop.  